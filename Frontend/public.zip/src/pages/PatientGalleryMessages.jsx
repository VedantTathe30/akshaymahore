import React, { useState, useEffect } from 'react';
import axiosInstance from '../config/axios';
import { API_URL } from '../config/api';
import { FaEnvelope, FaPhone, FaTimes, FaSpinner, FaReply } from 'react-icons/fa';
import toast, { Toaster } from 'react-hot-toast';

const PatientGalleryMessages = () => {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedMessage, setSelectedMessage] = useState(null);
  const [showReplyForm, setShowReplyForm] = useState(false);
  const [replyData, setReplyData] = useState({
    senderName: '',
    senderEmail: '',
    senderMobile: '',
    message: ''
  });

  useEffect(() => {
    fetchMessages();
  }, []);

  const fetchMessages = async () => {
    try {
      setLoading(true);
      const response = await axiosInstance.get(`${API_URL}/patient-gallery-messages`);
      
      if (response.data.success) {
        setMessages(response.data.data);
      } else {
        setError('Failed to load messages');
      }
    } catch (err) {
      console.error('Error fetching messages:', err);
      setError('Error loading messages');
    } finally {
      setLoading(false);
    }
  };

  const handleReply = async (messageId) => {
    if (!replyData.senderName || !replyData.message) {
      toast.error('Sender name and message are required');
      return;
    }

    try {
      const response = await axiosInstance.post(`${API_URL}/patient-gallery-messages`, {
        patientGalleryId: selectedMessage.patientGalleryId,
        patientName: selectedMessage.patientName,
        senderName: replyData.senderName,
        senderEmail: replyData.senderEmail,
        senderMobile: replyData.senderMobile,
        message: replyData.message
      });

      if (response.data.success) {
        toast.success('Reply sent successfully');
        setReplyData({ senderName: '', senderEmail: '', senderMobile: '', message: '' });
        setShowReplyForm(false);
        fetchMessages(); // Refresh messages
      } else {
        toast.error('Failed to send reply');
      }
    } catch (err) {
      console.error('Error sending reply:', err);
      toast.error('Failed to send reply');
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <FaSpinner className="animate-spin text-4xl text-blue-600 mx-auto mb-4" />
        <p className="text-gray-600">Loading messages...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-red-600 text-lg">{error}</p>
        <button 
          onClick={() => fetchMessages()}
          className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-900">Patient Gallery Messages</h1>
        <button
          onClick={() => setShowReplyForm(true)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
        >
          <FaReply className="mr-2" /> New Message
        </button>
      </div>

      {/* Reply Form Modal */}
      {showReplyForm && selectedMessage && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Reply to Message</h2>
              <button
                onClick={() => setShowReplyForm(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <FaTimes />
              </button>
            </div>
            </div>

            <form onSubmit={handleReply} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Your Name *
                </label>
                <input
                  type="text"
                  name="senderName"
                  value={replyData.senderName}
                  onChange={(e) => setReplyData({ ...replyData, senderName: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Your Email *
                </label>
                <input
                  type="email"
                  name="senderEmail"
                  value={replyData.senderEmail}
                  onChange={(e) => setReplyData({ ...replyData, senderEmail: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Your Mobile *
                </label>
                <input
                  type="text"
                  name="senderMobile"
                  value={replyData.senderMobile}
                  onChange={(e) => setReplyData({ ...replyData, senderMobile: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Message *
                </label>
                <textarea
                  name="message"
                  value={replyData.message}
                  onChange={(e) => setReplyData({ ...replyData, message: e.target.value })}
                  rows="4"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
                >
                  Send Reply
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowReplyForm(false);
                    setReplyData({ senderName: '', senderEmail: '', senderMobile: '', message: '' });
                  }}
                  className="bg-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-400"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Messages List */}
      <div className="bg-white rounded-xl shadow overflow-hidden">
        {messages.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500">No messages found.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((message, index) => (
              <div key={message._id} className="bg-white rounded-lg shadow p-6 border border-gray-200">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">
                      {message.patientName}
                    </h3>
                    <div className="text-sm text-gray-600 mb-2">
                      <div className="flex items-center">
                        <FaEnvelope className="mr-2" />
                        <span>{message.senderEmail || message.senderMobile}</span>
                      </div>
                      <div className="flex items-center">
                        <FaPhone className="mr-2" />
                        <span>{message.senderMobile || 'No mobile'}</span>
                      </div>
                    </div>
                    </div>
                    <p className="text-sm text-gray-500 mb-2">
                      {formatDate(message.createdAt)}
                    </p>
                  </div>
                  <div className="flex justify-end">
                    <button
                      onClick={() => setSelectedMessage(message)}
                      className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                    >
                      <FaReply className="mr-1" /> Reply
                    </button>
                  </div>
                </div>

                <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                  <p className="text-gray-700">{message.message}</p>
                  
                  {!message.isRead && (
                    <div className="flex items-center mt-2">
                      <span className="inline-block w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                      <span className="text-sm text-gray-600">New</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Toaster position="top-right" />
    </div>
  );
};

export default PatientGalleryMessages;
