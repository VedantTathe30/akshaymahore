import React, { useState, useEffect } from 'react';
import { FaCalendarAlt, FaUser, FaSpinner } from 'react-icons/fa';
import { API_URL } from '../config/api';
import axiosInstance from '../config/axios';

const PatientGallery = () => {
  const [galleryItems, setGalleryItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedItem, setSelectedItem] = useState(null);

  useEffect(() => {
    fetchPatientGallery();
  }, []);

  const fetchPatientGallery = async () => {
    try {
      console.log('=== FRONTEND PUBLIC GALLERY DEBUG ===');
      setLoading(true);
      const response = await axiosInstance.get(`${API_URL}/patient-gallery/public`);
      
      console.log('Public gallery response:', response);
      console.log('Response data:', response.data);
      
      if (response.data.success) {
        console.log('Setting gallery items:', response.data.data);
        setGalleryItems(response.data.data);
      } else {
        console.log('Response success was false');
        setError('Failed to load patient gallery');
      }
    } catch (err) {
      console.error('Error fetching patient gallery:', err);
      console.error('Error response:', err.response);
      setError('Error loading patient gallery');
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  const getImageUrl = (photo) => {
    return `${API_URL}/uploads/patient-gallery/${photo.filename}`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <FaSpinner className="animate-spin text-4xl text-blue-600 mx-auto mb-4" />
          <p className="text-gray-600">Loading patient gallery...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 text-lg mb-4">{error}</p>
          <button 
            onClick={fetchPatientGallery}
            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Patient Success Stories
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Witness the transformative results of homoeopathic treatment through our patients' before and after journeys
          </p>
        </div>

        {/* Gallery Grid */}
        {galleryItems.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">No patient stories available at the moment.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {galleryItems.map((item) => (
              <div 
                key={item._id} 
                className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow cursor-pointer"
                onClick={() => setSelectedItem(item)}
              >
                {/* Before/After Images */}
                <div className="relative">
                  <div className="grid grid-cols-2 gap-0">
                    {/* Before Image */}
                    <div className="relative">
                      <img
                        src={getImageUrl(item.beforePhoto)}
                        alt="Before treatment"
                        className="w-full h-48 object-cover"
                      />
                      <div className="absolute top-2 left-2 bg-red-600 text-white px-2 py-1 rounded text-xs font-semibold">
                        BEFORE
                      </div>
                    </div>
                    
                    {/* After Image */}
                    <div className="relative">
                      <img
                        src={getImageUrl(item.afterPhoto)}
                        alt="After treatment"
                        className="w-full h-48 object-cover"
                      />
                      <div className="absolute top-2 right-2 bg-green-600 text-white px-2 py-1 rounded text-xs font-semibold">
                        AFTER
                      </div>
                    </div>
                  </div>
                </div>

                {/* Patient Info */}
                <div className="p-6">
                  <div className="flex items-center mb-3">
                    <FaUser className="text-gray-400 mr-2" />
                    <h3 className="text-lg font-semibold text-gray-900">
                      {item.patientName}
                    </h3>
                  </div>
                  
                  <div className="flex items-center mb-3 text-sm text-gray-600">
                    <FaCalendarAlt className="mr-2" />
                    <span>{formatDate(item.treatmentDate)}</span>
                  </div>

                  <button className="mt-4 text-blue-600 hover:text-blue-800 text-sm font-medium">
                    View Full Story →
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Modal for Selected Item */}
        {selectedItem && (
          <div 
            className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4"
            onClick={() => setSelectedItem(null)}
          >
            <div 
              className="bg-white rounded-xl max-w-6xl w-full max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6">
                {/* Header */}
                <div className="flex justify-between items-start mb-6">
                  <div>
                    <h2 className="text-2xl font-bold text-gray-900 mb-2">
                      {selectedItem.patientName}
                    </h2>
                    <p className="text-gray-600">
                      Treatment Date: {formatDate(selectedItem.treatmentDate)}
                    </p>
                  </div>
                  <button
                    onClick={() => setSelectedItem(null)}
                    className="text-gray-400 hover:text-gray-600 text-2xl"
                  >
                    ×
                  </button>
                </div>

                {/* Before/After Comparison */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                  <div>
                    <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                      <h3 className="text-lg font-semibold text-red-800 mb-3">Before Treatment</h3>
                      <img
                        src={getImageUrl(selectedItem.beforePhoto)}
                        alt="Before treatment"
                        className="w-full rounded-lg"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                      <h3 className="text-lg font-semibold text-green-800 mb-3">After Treatment</h3>
                      <img
                        src={getImageUrl(selectedItem.afterPhoto)}
                        alt="After treatment"
                        className="w-full rounded-lg"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PatientGallery;
